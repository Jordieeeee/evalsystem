import { db } from './firebase';
import { collection, query, where, getDocs, doc, getDoc, addDoc } from 'firebase/firestore';

export const evaluationService = {
  
  // 1. Fetch a student's passed history
  getStudentHistory: async (studentId) => {
    const evalRef = collection(db, 'evaluations');
    const q = query(
      evalRef, 
      where("studentId", "==", studentId),
      where("status", "==", "Passed")
    );
    const snapshot = await getDocs(q);
    return snapshot.docs.map(doc => doc.data());
  },

  // 2. The Prerequisite Checker
  checkEligibility: async (studentId, subjectCodeToTake) => {
    // Get the subject requirements
    const subjectRef = doc(db, 'subjects', subjectCodeToTake);
    const subjectSnap = await getDoc(subjectRef);
    
    if (!subjectSnap.exists()) throw new Error("Subject not found");
    const requiredPrereqs = subjectSnap.data().prerequisites || [];

    // If no prerequisites, they are automatically eligible
    if (requiredPrereqs.length === 0) return { eligible: true, missing: [] };

    // Get the student's passed courses
    const history = await evaluationService.getStudentHistory(studentId);
    
    // Map the history to a simple array of passed course codes
    const passedCodes = history.map(record => record.subjectCode);

    // Identify any missing prerequisites
    const missingPrereqs = requiredPrereqs.filter(prereq => !passedCodes.includes(prereq));

    return {
      eligible: missingPrereqs.length === 0,
      missing: missingPrereqs
    };
  },

  // 3. Dispatch an Assignment (Used in your AdminEvaluationPage)
  dispatchAssignment: async (studentId, subjectCode) => {
    const eligibility = await evaluationService.checkEligibility(studentId, subjectCode);
    
    const newEvaluation = {
      studentId,
      subjectCode,
      status: eligibility.eligible ? 'Assigned' : 'Pending Pre-req',
      assignedDate: new Date().toISOString(),
      missingPrerequisites: eligibility.missing
    };

    await addDoc(collection(db, 'evaluations'), newEvaluation);
    return newEvaluation;
  }
};