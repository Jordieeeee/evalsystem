import { db } from './firebase';
import { collection, query, where, getDocs, doc, getDoc } from 'firebase/firestore';

export const studentService = {
  // Get main profile data
  getProfile: async (studentId) => {
    const docRef = doc(db, 'students', studentId);
    const snap = await getDoc(docRef);
    return snap.exists() ? snap.data() : null;
  },

  // Get active assignments and historical grades
  getAcademicRecords: async (studentId) => {
    const recordsRef = collection(db, 'evaluations');
    const q = query(recordsRef, where("studentId", "==", studentId));
    const snapshot = await getDocs(q);
    
    const allRecords = snapshot.docs.map(doc => doc.data());
    
    // Separate current assignments from completed grades
    const currentSubjects = allRecords.filter(r => r.status === 'Assigned' || r.status === 'Pending Pre-req');
    const completedHistory = allRecords.filter(r => r.status === 'Passed' || r.status === 'Failed');

    return { currentSubjects, completedHistory };
  }
};