import { db } from './firebase';
import { collection, getDocs, query, where } from 'firebase/firestore';

export const subjectService = {
  // Fetch all subjects for the admin catalog
  getAllSubjects: async () => {
    const subjectsRef = collection(db, 'subjects');
    const snapshot = await getDocs(subjectsRef);
    return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
  },

  // Fetch subjects specific to a student's curriculum track
  getSubjectsByTrack: async (trackVersion) => {
    const subjectsRef = collection(db, 'subjects');
    const q = query(subjectsRef, where("curriculumTracks", "array-contains", trackVersion));
    const snapshot = await getDocs(q);
    return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
  }
};